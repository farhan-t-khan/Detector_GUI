#pragma once
#include "Settings.h"
class CDetectorguiDlg;
class CBlueTooth
{
   CBlueTooth();
   CSettings& m_Settings = *CSettings::GetInstance();
public:
   static CCriticalSection m_st_CS;
   //	Stop_Sampling		Mode = 0
   //	Start_Sampling		Mode = 1
   //	Idle			Mode = 2
   //	Calibrate		Mode = 3
   //	Dump_Data		Mode = 4;
   //	Download Code		Mode = 5;
   //	Read Flash Block	Mode = 6;
   //	Write Flash Block	Mode = 7;
   enum Status
   {
      Stop_Sampling = 0, Start_Sampling, Idle, Calibrate, Dump_Data, Download_Code, Read_Flash_Block, Write_Flash_Block
   };
   static CBlueTooth& GetInstance(void);
   CDetectorguiDlg* m_pMainGui = 0;
	~CBlueTooth();
	SOCKET 		BtSocket = INVALID_SOCKET;
	bool btConnected;
	int Mode = 0;
   int saved_mode = 0;
	// runs in initdialoge to connect bluetooth device on startup
	int Look_For_Bluetooth_Devices();
	int ReadBluetooth(unsigned char *ptr);
	void Send_TEC_Parameters();
	void flush();
	int Sample_Data_And_Display(HANDLE hCom);
	friend UINT App_Thread(LPVOID pParam);
	void read_flash_block();
	void write_flash_block();
	unsigned char Flash_Block[1536];
	static void UpdateCRC8(unsigned char c);
	void download_new_program();
 //  BOOL ExtractGPSBuffer(char* sGPSBuffer, CString GPSTime, CString GPSLat, CString GPSLon, CString GPSHDOP, CString GPSnSat);

};

