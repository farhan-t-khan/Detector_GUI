#include "stdafx.h"
#include "CBlueTooth.h"
#include "Detector_guiDlg.h"
#include "afxdialogex.h"
#include "math.h"
#include "mmsystem.h"
#include "windowsx.h"
#include "string.h"
#include <ctime>
#include "SerialGPS.h"
#include "NMEAParser.h"
#include "GPSInfo.h"
#include <string.h>
#include <stdlib.h>
#include "Profiler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CBlueTooth::CBlueTooth()
{
}


CBlueTooth::~CBlueTooth()
{
}

#include "wchar.h"
#include "stdio.h"

#include <Winsock2.h>
#include <wtypes.h>
#include <ws2bth.h>
#pragma comment(lib, "Ws2_32.lib")

unsigned char TableCrc8[256] = {
0x0, 0x5E, 0xBC, 0xE2, 0x61, 0x3F, 0xDD, 0x83, 0xC2, 0x9C, 0x7E, 0x20, 0xA3, 0xFD, 0x1F, 0x41,
0x9D, 0xC3, 0x21, 0x7F, 0xFC, 0xA2, 0x40, 0x1E, 0x5F, 0x1, 0xE3, 0xBD, 0x3E, 0x60, 0x82, 0xDC,
0x23, 0x7D, 0x9F, 0xC1, 0x42, 0x1C, 0xFE, 0xA0, 0xE1, 0xBF, 0x5D, 0x3, 0x80, 0xDE, 0x3C, 0x62,
0xBE, 0xE0, 0x2, 0x5C, 0xDF, 0x81, 0x63, 0x3D, 0x7C, 0x22, 0xC0, 0x9E, 0x1D, 0x43, 0xA1, 0xFF,
0x46, 0x18, 0xFA, 0xA4, 0x27, 0x79, 0x9B, 0xC5, 0x84, 0xDA, 0x38, 0x66, 0xE5, 0xBB, 0x59, 0x7,
0xDB, 0x85, 0x67, 0x39, 0xBA, 0xE4, 0x6, 0x58, 0x19, 0x47, 0xA5, 0xFB, 0x78, 0x26, 0xC4, 0x9A,
0x65, 0x3B, 0xD9, 0x87, 0x4, 0x5A, 0xB8, 0xE6, 0xA7, 0xF9, 0x1B, 0x45, 0xC6, 0x98, 0x7A, 0x24,
0xF8, 0xA6, 0x44, 0x1A, 0x99, 0xC7, 0x25, 0x7B, 0x3A, 0x64, 0x86, 0xD8, 0x5B, 0x5, 0xE7, 0xB9,
0x8C, 0xD2, 0x30, 0x6E, 0xED, 0xB3, 0x51, 0xF, 0x4E, 0x10, 0xF2, 0xAC, 0x2F, 0x71, 0x93, 0xCD,
0x11, 0x4F, 0xAD, 0xF3, 0x70, 0x2E, 0xCC, 0x92, 0xD3, 0x8D, 0x6F, 0x31, 0xB2, 0xEC, 0xE, 0x50,
0xAF, 0xF1, 0x13, 0x4D, 0xCE, 0x90, 0x72, 0x2C, 0x6D, 0x33, 0xD1, 0x8F, 0xC, 0x52, 0xB0, 0xEE,
0x32, 0x6C, 0x8E, 0xD0, 0x53, 0xD, 0xEF, 0xB1, 0xF0, 0xAE, 0x4C, 0x12, 0x91, 0xCF, 0x2D, 0x73,
0xCA, 0x94, 0x76, 0x28, 0xAB, 0xF5, 0x17, 0x49, 0x8, 0x56, 0xB4, 0xEA, 0x69, 0x37, 0xD5, 0x8B,
0x57, 0x9, 0xEB, 0xB5, 0x36, 0x68, 0x8A, 0xD4, 0x95, 0xCB, 0x29, 0x77, 0xF4, 0xAA, 0x48, 0x16,
0xE9, 0xB7, 0x55, 0xB, 0x88, 0xD6, 0x34, 0x6A, 0x2B, 0x75, 0x97, 0xC9, 0x4A, 0x14, 0xF6, 0xA8,
0x74, 0x2A, 0xC8, 0x96, 0x15, 0x4B, 0xA9, 0xF7, 0xB6, 0xE8, 0xA, 0x54, 0xD7, 0x89, 0x6B, 0x35,
};

#define BT_MAX_INQUIRY_RETRY	3
#define BT_SUCCESS		0
#define BT_ERROR		1
#define BTArraySize 		5


struct BlueToothList
{
   char	mac[20];
   int	NameSnCount;
   char	name[100];
};

//
//	This is what the structure looks like but we are sending this out
//	as a stream of bytes since the structure alignment and padding is 
//	different between the micro and tablet
//

#define txsize  50
#define rxsize	txsize - 6
unsigned char	rx1[rxsize];

/*
rx1[0]	=	0xAA;
rx1[1]	=	0xBB;

rx1[2]	=	Type of packet

rx1[3]	=	CH4 Sample
rx1[4]	=	CH4 Sample

rx1[5]	=	Tec Temp
rx1[6]	=	Tec Temp

rx1[7]	=	Tec Current
rx1[8]	=	Tec Current

rx1[9]	=	Tec Error
rx1[10]	=	Tec Error

rx1[11]	=	GPS Long
rx1[12]	=	GPS Long
rx1[13]	=	GPS Long
rx1[14]	=	GPS Long

rx1[15]	=	GPS Lat
rx1[16]	=	GPS Lat
rx1[17]	=	GPS Lat
rx1[18]	=	GPS Lat

rx1[19] = 	Battery Voltage
rx1[20] = 	Battery Voltage

rx1[21] = 	Laser Temperature
rx1[22] = 	Laser Temperature

rx1[23] = 	Receiver Temperature
rx1[24] = 	Receiver Temperature

rx1[25] = 	Laser Humidity
rx1[26] = 	Laser Humidity

rx1[27] = 	Receiver Humidity
rx1[28] = 	Receiver Humidity

rx1[29]	=
rx1[30]	=
rx1[31]	=
rx1[32]	=
rx1[33]	=
rx1[34]	=
rx1[35]	=
rx1[36]	=
rx1[37]	=
rx1[38]	=
rx1[39]	=
rx1[40]	=
rx1[41]	=
rx1[42]	=
rx1[43]	=	CRC8

*/


struct		BlueToothList *BT[BTArraySize] = { 0 };
//int		Mode = 0;
int		checksum_errors = 0;
unsigned 	char Crc8;
//int		first_time;
//int		ppmalarmlevel;
int		alarm_active;
int		alarm_muted;

//int		graph_left;
//int		graph_top;
//int		graph_right;
//int		graph_bottom;
//int		graph_width;
//int		graph_height;

//int		graph_ppm;
//int		graph_x;
//int		graph_y;
//int		last_graph_x;
//int		last_graph_y;

//int 		saved_mode;

int		maxvalue;
int		minvalue;
int		maxmincount;

clock_t start, now, GpsStart, GpsNow;

CCriticalSection CBlueTooth::m_st_CS;
CBlueTooth& CBlueTooth::GetInstance(void)
{
   CSingleLock lock(&m_st_CS, TRUE);
   static CBlueTooth st_BlueToothOnlyInstance;
   return st_BlueToothOnlyInstance;
}

// runs in initdialog to connect bluetooth device on startup
int CBlueTooth::Look_For_Bluetooth_Devices()
{
   // TODO: Add your implementation code here.
   int steveerror;
   ULONG		ulRetCode;
   WSADATA		WSAData = { 0 };
   SOCKADDR_BTH	RemoteBthAddr = { 0 };
   INT             iResult = BT_SUCCESS;
   BOOL            bContinueLookup = FALSE, bRemoteDeviceFound = FALSE;
   ULONG           ulFlags = 0, ulPQSSize = sizeof(WSAQUERYSET);
   HANDLE          hLookup = NULL;
   PWSAQUERYSET	pWSAQuerySet = NULL;
   int xx;
   char rcv_buf[16];
   int x, y, n;
   int found;
   unsigned char IR[] = { "BASCOMTURNER" };
   //unsigned char IR[]={"BASCOM-TURNER-IR-42C3"};
   //unsigned char IR[]={"BASCOM-TURNER-8C6F"};

   HANDLE 		keyboard;
   DWORD		mode;
   DWORD 		NumEvents;
   unsigned char steve[50];

   for (xx = 0; xx < BTArraySize; ++xx)
      BT[xx] = (struct BlueToothList *)calloc(1, sizeof(struct BlueToothList));

   // Initialize WinSock.
   ulRetCode = WSAStartup(MAKEWORD(2, 2), &WSAData);

   pWSAQuerySet = (PWSAQUERYSET)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, ulPQSSize);
   if (NULL == pWSAQuerySet)
   {
      iResult = STATUS_NO_MEMORY;
      m_pMainGui->wPrintf(_T("!ERROR! | Unable to allocate memory for WSAQUERYSET\n"));
      for (x = 0; x < BTArraySize; ++x)
      {
         free(BT[x]);
         BT[x] = 0;
      }
      return false;
   }

   //
   // Search for the device with the correct name
   //
   if (iResult == BT_SUCCESS)
   {
      for (INT iRetryCount = 0; !bRemoteDeviceFound && (iRetryCount < BT_MAX_INQUIRY_RETRY); iRetryCount++)
      {
         //
         // WSALookupService is used for both service search and device inquiry
         // LUP_CONTAINERS is the flag which signals that we're doing a device inquiry.
         //
         ulFlags = LUP_CONTAINERS;

         //
         // Friendly device name (if available) will be returned in lpszServiceInstanceName
         //
         ulFlags |= LUP_RETURN_NAME;

         //
         // BTH_ADDR will be returned in lpcsaBuffer member of WSAQUERYSET
         //
         ulFlags |= LUP_RETURN_ADDR;

         if (0 == iRetryCount)
         {
         }
         else
         {
            //
            // Flush the device cache for all inquiries, except for the first inquiry
            //
            // By setting LUP_FLUSHCACHE flag, we're asking the lookup service to do
            // a fresh lookup instead of pulling the information from device cache.
            //

            ulFlags |= LUP_FLUSHCACHE;

            //
            // Pause for some time before all the inquiries after the first inquiry
            //
            // Remote Name requests will arrive after device inquiry has
            // completed.  Without a window to receive IN_RANGE notifications,
            // we don't have a direct mechanism to determine when remote
            // name requests have completed.
            //
         }


         //
         // Start the lookup service
         //
         iResult = BT_SUCCESS;
         hLookup = 0;
         bContinueLookup = FALSE;
         ZeroMemory(pWSAQuerySet, ulPQSSize);
         pWSAQuerySet->dwNameSpace = NS_BTH;
         pWSAQuerySet->dwSize = sizeof(WSAQUERYSET);

         iResult = WSALookupServiceBegin(pWSAQuerySet, ulFlags, &hLookup);

         //
         // Even if we have an error, we want to continue until we
         // reach the CXN_MAX_INQUIRY_RETRY
         //
         if ((NO_ERROR == iResult) && (NULL != hLookup))
         {
            bContinueLookup = TRUE;
         }
         else if (0 < iRetryCount)
         {
            break;
         }

         while (bContinueLookup)
         {
            if (m_pMainGui->m_st_nTerminaThread) break;
            //
            // Get information about next bluetooth device
            //
            // Note you may pass the same WSAQUERYSET from LookupBegin
            // as long as you don't need to modify any of the pointer
            // members of the structure, etc.
            //
            if (NO_ERROR == WSALookupServiceNext(hLookup, ulFlags, &ulPQSSize, pWSAQuerySet))
            {
               // Compare the name to see if this is the device we are looking for.

               found = 0;

               //for(xx=0;xx<100;++xx)
               //	BT[0]->name[xx] = 0;


               for (xx = 0; xx < 100; ++xx)
               {
                  if (pWSAQuerySet->lpszServiceInstanceName[xx] == 0)
                     break;
                  found = 1;
                  BT[0]->name[xx] = pWSAQuerySet->lpszServiceInstanceName[xx];
               }

               found = 1;
               //pMainGui->wPrintf("%s ",&BT[0]->name[0]);

               if (pWSAQuerySet->lpszServiceInstanceName != NULL)
               {
                  //						for(xx=0;xx<18;++xx)
                  for (xx = 0; xx < 12; ++xx)
                  {
                     if (pWSAQuerySet->lpszServiceInstanceName[xx] != IR[xx])
                     {
                        found = 0;
                        break;
                     }
                  }
               }

               if (iRetryCount == 0)
                  found = 0;

               if (found == 1)
               {
                  CopyMemory(&RemoteBthAddr,
                     (PSOCKADDR_BTH)pWSAQuerySet->lpcsaBuffer->RemoteAddr.lpSockaddr,
                     sizeof(RemoteBthAddr));
                  bRemoteDeviceFound = TRUE;
                  bContinueLookup = FALSE;
               }
            }
            else
            {
               iResult = WSAGetLastError();
               if (WSA_E_NO_MORE == iResult)
               {
                  //
                  // No more devices found.  Exit the lookup.
                  //
                  bContinueLookup = FALSE;
               }
               else if (WSAEFAULT == iResult)
               {
                  //
                  // The buffer for QUERYSET was insufficient.
                  // In such case 3rd parameter "ulPQSSize" of function "WSALookupServiceNext()" receives
                  // the required size.  So we can use this parameter to reallocate memory for QUERYSET.
                  //
                  HeapFree(GetProcessHeap(), 0, pWSAQuerySet);
                  pWSAQuerySet = (PWSAQUERYSET)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, ulPQSSize);
                  if (NULL == pWSAQuerySet)
                  {
                     m_pMainGui->wPrintf(_T("!ERROR! | Unable to allocate memory for WSAQERYSET\n"));
                     iResult = STATUS_NO_MEMORY;
                     bContinueLookup = FALSE;
                  }
               }
               else
               {
                  m_pMainGui->wPrintf(_T("=CRITICAL= | WSALookupServiceNext() failed with error code %d\n"), iResult);
                  bContinueLookup = FALSE;
               }
            }
         }

         //
         // End the lookup service
         //
         WSALookupServiceEnd(hLookup);

         if (iResult == STATUS_NO_MEMORY)
            break;
      }
   }

   if (NULL != pWSAQuerySet)
   {
      HeapFree(GetProcessHeap(), 0, pWSAQuerySet);
      pWSAQuerySet = NULL;
   }

   if (!bRemoteDeviceFound)
   {
      iResult = BT_ERROR;
      WSACleanup();
      for (x = 0; x < BTArraySize; ++x)
      {
         free(BT[x]);
         BT[x] = 0;
      }
      return false;
   }


   RemoteBthAddr.addressFamily = AF_BTH;
   RemoteBthAddr.serviceClassId = RFCOMM_PROTOCOL_UUID;
   RemoteBthAddr.port = 0;

   //
   // Open a bluetooth socket using RFCOMM protocol
   //
   BtSocket = socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
   if (INVALID_SOCKET == BtSocket)
   {
      ulRetCode = ERROR;
      WSACleanup();
      for (x = 0; x < BTArraySize; ++x)
      {
         free(BT[x]);
         BT[x] = 0;
      }
      return false;
   }

   // Set timeout on socket
   int iOptVal = 25;
   int iOptLen = sizeof(int);
   iOptVal = 8192;
   steveerror = setsockopt(BtSocket, SOL_SOCKET, SO_RCVBUF, (char *)&iOptVal, iOptLen);
   iOptVal = 10;
   steveerror = setsockopt(BtSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&iOptVal, iOptLen);

   //
   // Connect the socket (pSocket) to a given remote socket represented by address (pServerAddr)
   //
   if (SOCKET_ERROR == connect(BtSocket, (struct sockaddr *) &RemoteBthAddr, sizeof(SOCKADDR_BTH)))
   {


      //steveerror = WSAGetLastError();
      //pMainGui->wPrintf(_T("%d "),steveerror);

      ulRetCode = ERROR;
      WSACleanup();
      for (x = 0; x < BTArraySize; ++x)
      {
         free(BT[x]);
         BT[x] = 0;
      }
      return false;
   }

   Sleep(100);

   // flush the buffer
//		x = 0;
//		while (x != -1)
//			x = recv(BtSocket,(char *)rcv_buf,(int)sizeof(rcv_buf),0);
   for (x = 0; x < BTArraySize; ++x)
   {
      free(BT[x]);
      BT[x] = 0;
   }
   return true;
}


int CBlueTooth::ReadBluetooth(unsigned char *ptr)
{
#ifdef USE_PROFILER
   CProfiler func("CBlueTooth::ReadBluetooth");
#endif
   // TODO: Add your implementation code here.
   int		nbytes, result;
   unsigned long 	numbytes;
   time_t ltime;
   time_t exp_time;

   time(&ltime);
   exp_time = ltime + 3;

   fd_set readfds;
   readfds.fd_count = 1;
   readfds.fd_array[0] = BtSocket;
   struct timeval timeout;
   timeout.tv_sec = 3;
   timeout.tv_usec = 0;
   int nRead = select(0, &readfds, 0, 0, &timeout);
   if (nRead)
   {
      nbytes = recv(BtSocket, (char *)ptr, rxsize, 0);

      if (nbytes == 0)
      {
         m_pMainGui->wPrintf(_T("FIN detected"));
      }
      if (nbytes == SOCKET_ERROR)
      {
         int nError = WSAGetLastError();
         m_pMainGui->wPrintf(_T("WSAGetLastError=%d"), nError);
      }

      if (ptr[0] != 0xAA || ptr[1] != 0xBB)
         m_pMainGui->wPrintf(_T("Header did not match"));

      return(nbytes);
   }
   else
   {
      m_pMainGui->wPrintf(_T("Error-select=%d"), nRead);
   }
   return -1;
   for (;;)
   {
      result = ioctlsocket(BtSocket, FIONREAD, &numbytes);
      if (result != NO_ERROR)
         m_pMainGui->wPrintf(_T("Error=%d"), result);

      time(&ltime);
      if (ltime >= exp_time)
      {
         m_pMainGui->wPrintf(_T("timeout"));
         return(-1);
      }


      if (this->Mode == 0)
         return(0);

      if (numbytes < rxsize)
         continue;

      nbytes = recv(BtSocket, (char *)ptr, rxsize, 0);

      if (ptr[0] != 0xAA || ptr[1] != 0xBB)
         m_pMainGui->wPrintf(_T("Header did not match"));

      return(nbytes);
   }
}


void CBlueTooth::Send_TEC_Parameters()
{
   // TODO: Add your implementation code here.
   FILE *stream;
   unsigned char buffer[1000];
   unsigned char output[1000];
   char str_temp[5];
   unsigned int   Tec_Set_Temp;
   int i, x, y, z, sent, c, length;


   if ((stream = fopen("C:\\BascomTurner\\TEC.txt", "r")) != NULL)
   {
      for (x = 0; x < 1000; ++x)
         buffer[x] = 0;

      for (x = 0; x < 1000; ++x)
         output[x] = 0;

      output[0] = 'T';
      output[1] = 'E';
      output[2] = 'C';
      output[3] = 'W';
      output[4] = ' ';
      i = fread(&buffer[0], 1, 1000, stream);

      y = 5;
      x = 0;

      for (;;)
      {
         output[y] = buffer[x];
         if (output[y] == 10)
         {
            if (output[5] == 84) {
               c = 0;
               length = y - 6;
               while (c < length) {
                  str_temp[c] = output[6 + c];
                  c++;
               }
               Tec_Set_Temp = atoi(str_temp);
            }
            sent = send(BtSocket, (char *)output, y + 1, 0);
            Sleep(300);
            y = 5;
         }
         else
            y = y + 1;

         x = x + 1;
         if (x == i)
            break;
      }
      fclose(stream);
   }
}


void CBlueTooth::flush()
{
#ifdef USE_PROFILER
   CProfiler func(__FUNCDNAME__);
#endif
   // TODO: Add your implementation code here.
   int x;
   char rcv_buf[16];

   //
   //	flush Bluetooth buffer
   //
   x = 0;
   while (x != -1)
      x = recv(BtSocket, (char *)rcv_buf, (int)sizeof(rcv_buf), 0);
}

TCHAR* TimeandDateStr(TCHAR* szBuff, UINT nLength)
{
#ifdef USE_PROFILER
   CProfiler func(__FUNCDNAME__);
#endif
   SYSTEMTIME systemTime = { 0 };
   GetLocalTime(&systemTime);
   _sntprintf(szBuff, nLength, _T("%02d:%02d:%02d.%03d"), systemTime.wHour,
      systemTime.wMinute, systemTime.wSecond, systemTime.wMilliseconds);
   //struct tm* time_now;
   //time_t secs_now;
   //time(&secs_now);
   //time_now = localtime(&secs_now);
   //_tcsftime(szBuff, nLength, _T("%H:%M:%S , %m-%d-%Y"), localtime(&secs_now));
   return szBuff;
}

int CBlueTooth::Sample_Data_And_Display(HANDLE hCom)
{
#ifdef USE_PROFILER
   CProfiler func(__FUNCDNAME__);
#endif
   // TODO: Add your implementation code here.
   int x, y, nbytes;
   int counter = 0;
   //unsigned char buff1[40];
   //unsigned char buff2[40];
   //unsigned char *ptr;
   CString sLabel;
   char buff1[40];
   char buff2[40];
   char *ptr;
   short sample;
   long lat, lon;
   DOUBLE GpsLat = 0.0, GpsLon = 0.0;
   float GpsHDOP;
   int GpsNSat;
   short latlon;
   BOOL bReadRC;
   char sGPSBuffer[1024];
   DWORD iBytesRead;
   BOOL bExtractGPS;
   ULONG er;
   COMSTAT lp;
   char szBuffer[40];


   MyNMEA MyGps;// = new MyNMEA;
   PurgeComm(hCom, PURGE_RXCLEAR);
   for (;;)
   {
      while (m_pMainGui->PauseBlueToothThread())
      {
         Sleep(1000);
      }
      if (Mode != 1)
      {
         return(0);
      }
#ifdef USE_PROFILER
      CProfiler func("Sample_Data_And_Display for loop");
#endif
      
      nbytes = ReadBluetooth((unsigned char *)rx1);
      if (nbytes == -1)
         return(-1);

      Crc8 = 0;
      for (x = 0; x < rxsize - 1; ++x)
         UpdateCRC8(rx1[x]);

      if (Crc8 != rx1[rxsize - 1])
      {
         ++checksum_errors;
         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         sprintf((char *const)&buff2[0], "%d", checksum_errors);
         //cheksum->SetSel(0, -1);
         //cheksum->Clear();
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         buff1[8] = buff2[4];
         buff1[10] = buff2[5];
         //cheksum->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         flush();
         continue;
      }

      ptr = (char *)&sample;
      ptr[0] = rx1[3];
      ptr[1] = rx1[4];
      m_Settings.graph_ppm = sample;
      float fSample = sample / 10.0f;
      m_pMainGui->Plot_ppm(fSample);
      m_pMainGui->m_plotGraph.Updateppm(fSample);

      TCHAR szTime[64] = { 0 };
      TimeandDateStr(szTime, ARRAYSIZE(szTime));
      CString sInfo;
      if (fSample >= m_Settings.m_nAlarmLevel)
      {
         sInfo.Format(_T("%s,%.1f"), szTime, fSample);
         m_pMainGui->WriteToSurveyFileR(sInfo);
      }
      ClearCommError(hCom, &er, &lp);
      if (lp.cbInQue >= 75) {
         Sleep(10);
         for (x = 0; x < 1024; ++x)
            sGPSBuffer[x] = 0;
         bReadRC = ReadFile(hCom, &sGPSBuffer, 1024, &iBytesRead, NULL);
         if (iBytesRead != 0) {
            MyGps.ParseNMEASentence("GPGGA", (const char *)&sGPSBuffer, (UINT)iBytesRead);
            GpsLat = MyGps.m_GPSInfo.m_latitude;
            GpsLon = MyGps.m_GPSInfo.m_longitude;
            GpsNSat = MyGps.m_GPSInfo.m_satelitesInUse;
            GpsHDOP = MyGps.m_GPSInfo.m_signalQuality;
            


            sInfo.Format(_T("%s,%.06lf,%.06lf,%02d,%.01lf,%.01f"), szTime, GpsLat, GpsLon,
               GpsNSat, GpsHDOP, fSample);
            m_pMainGui->WriteToSurveyFile(sInfo);
         }
      }


      if (sample > 10 && sample < 40) m_Settings.BumpTestSucess();
      counter = counter + 1;
      if (counter == 30)
      {
         //for (x = 0; x < 40; ++x)
         //	buff1[x] = 0;
         //PPM->SetSel(0, -1);
         //PPM->Clear();
         //ptr = (char *)&sample;
         //ptr[0] = rx1[3];
         //ptr[1] = rx1[4];
         //m_Settings.graph_ppm = sample;
         //m_pMainGui->Plot_ppm(sample);
         //sprintf((char *const)&buff2[0], "%d", sample);
         //buff1[0] = buff2[0];
         //buff1[2] = buff2[1];
         //buff1[4] = buff2[2];
         //buff1[6] = buff2[3];
         //PPM->ReplaceSel((LPCTSTR)&buff1[0], FALSE);
         //m_pMainGui->m_plotGraph.Updateppm(sample/10);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //tec_temp->SetSel(0, -1);
         //tec_temp->Clear();
         ptr = (char *)&latlon;
         ptr[0] = rx1[5];
         ptr[1] = rx1[6];
         sprintf((char *const)&buff2[0], "%d", latlon);
         m_pMainGui->m_nTec_Temperature = latlon;
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         buff1[8] = buff2[4];
         //tec_temp->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //tec_curr->SetSel(0, -1);
         //tec_curr->Clear();
         ptr = (char *)&latlon;
         ptr[0] = rx1[7];
         ptr[1] = rx1[8];
         sprintf((char *const)&buff2[0], "%d", latlon);
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         buff1[8] = buff2[4];
         //tec_curr->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         for (x = 0; x < 40; ++x)
            buff2[x] = 0;

         //Latitude->SetSel(0, -1);
         //Latitude->Clear();
         ptr = (char *)&lat;
         //ptr[0] = rx1[11];
         //ptr[1] = rx1[12];
         //ptr[2] = rx1[13];
         //ptr[3] = rx1[14];
         if (GpsLat < 0.0) {
            _gcvt(GpsLat, 9, szBuffer);
         }
         else {
            _gcvt(GpsLat, 8, szBuffer);
         }
         sprintf((char *const)&buff2[0], "%s", szBuffer);
         sLabel.Format(_T("%06lf"), GpsLat);

         x = strlen(buff2) + 2;
         for (;;)
         {
            if (buff2[x] != 0)
               break;
            x = x - 1;
         }
         //buff2[x + 1] = buff2[x];
         //buff2[x] = buff2[x - 1];
         //buff2[x - 1] = buff2[x - 2];
         //buff2[x - 2] = buff2[x - 3];
         //buff2[x - 3] = buff2[x - 4];
         //buff2[x - 4] = buff2[x - 5];
         //buff2[x - 5] = buff2[x - 6];
         //buff2[x - 6] = '.';


         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         buff1[8] = buff2[4];
         buff1[10] = buff2[5];
         buff1[12] = buff2[6];
         buff1[14] = buff2[7];
         buff1[16] = buff2[8];
         buff1[18] = buff2[9];
         buff1[20] = buff2[10];
         buff1[22] = buff2[11];
         //Latitude->ReplaceSel((LPCTSTR)&buff1[0], FALSE);
         //wprintf(szBuffer, GpsLat);

         m_pMainGui->m_plotGraph.UpdateLat((LPCTSTR)sLabel);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         for (x = 0; x < 40; ++x)
            buff2[x] = 0;
         //Longitude->SetSel(0, -1);
         //Longitude->Clear();
         ptr = (char *)&lon;
         //ptr[0] = rx1[15];
         //ptr[1] = rx1[16];
         //ptr[2] = rx1[17];
         //ptr[3] = rx1[18];
         if (GpsLon < 0.0) {
            _gcvt(GpsLon, 9, szBuffer);
         }
         else {
            _gcvt(GpsLon, 8, szBuffer);
         }
         sprintf((char *const)&buff2[0], "%s", szBuffer);
         sLabel.Format(_T("%06lf"), GpsLon);

         x = 11;
         for (;;)
         {
            if (buff2[x] != 0)
               break;
            x = x - 1;
         }
         //buff2[x + 1] = buff2[x];
         //buff2[x] = buff2[x - 1];
         //buff2[x - 1] = buff2[x - 2];
         //buff2[x - 2] = buff2[x - 3];
         //buff2[x - 3] = buff2[x - 4];
         //buff2[x - 4] = buff2[x - 5];
         //buff2[x - 5] = buff2[x - 6];
         //buff2[x - 6] = '.';



         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         buff1[8] = buff2[4];
         buff1[10] = buff2[5];
         buff1[12] = buff2[6];
         buff1[14] = buff2[7];
         buff1[16] = buff2[8];
         buff1[18] = buff2[9];
         buff1[20] = buff2[10];
         buff1[22] = buff2[11];
         //Longitude->ReplaceSel((LPCTSTR)&buff1[0], FALSE);
         //wprintf(szBuffer, GpsLon);
         //_gcvt(GpsLon, 12, &szBuffer);
         m_pMainGui->m_plotGraph.UpdateLon((LPCTSTR)sLabel);


         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //Battery_Voltage->SetSel(0, -1);
         //Battery_Voltage->Clear();
         ptr = (char *)&sample;
         ptr[0] = rx1[19];
         ptr[1] = rx1[20];
         sprintf((char *const)&buff2[0], "%d", sample);
         m_pMainGui->m_nBattery_Voltage = sample;
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         //Battery_Voltage->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //Laser_Temperature->SetSel(0, -1);
         //Laser_Temperature->Clear();
         ptr = (char *)&sample;
         ptr[0] = rx1[21];
         ptr[1] = rx1[22];
         sprintf((char *const)&buff2[0], "%d", sample);
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];

         //Laser_Temperature->ReplaceSel((LPCTSTR)&buff1[0], FALSE);


         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //Receiver_Temperature->SetSel(0, -1);
         //Receiver_Temperature->Clear();
         ptr = (char *)&sample;
         ptr[0] = rx1[23];
         ptr[1] = rx1[24];
         sprintf((char *const)&buff2[0], "%d", sample);
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         //Receiver_Temperature->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //Laser_Humidity->SetSel(0, -1);
         //Laser_Humidity->Clear();
         ptr = (char *)&sample;
         ptr[0] = rx1[25];
         ptr[1] = rx1[26];
         sprintf((char *const)&buff2[0], "%d", sample);
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         //Laser_Humidity->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         for (x = 0; x < 40; ++x)
            buff1[x] = 0;
         //Receiver_Humidity->SetSel(0, -1);
         //Receiver_Humidity->Clear();
         ptr = (char *)&sample;
         ptr[0] = rx1[27];
         ptr[1] = rx1[28];
         sprintf((char *const)&buff2[0], "%d", sample);
         buff1[0] = buff2[0];
         buff1[2] = buff2[1];
         buff1[4] = buff2[2];
         buff1[6] = buff2[3];
         //Receiver_Humidity->ReplaceSel((LPCTSTR)&buff1[0], FALSE);

         counter = 0;
      }
      if (!m_pMainGui->IsAlarmDisabled())
      {
         now = std::clock();
         if (m_Settings.graph_ppm / 10 >= m_Settings.m_nAlarmLevel)//ppmalarmlevel)
         {
            start = std::clock();
            if (alarm_active == 0 && alarm_muted != 1) {

               PlaySound(m_Settings.m_sWavFile, NULL, SND_ASYNC | SND_LOOP);
               //PlaySound(TEXT("c:\\bascomturner\\program\\alarm.wav"), NULL, SND_ASYNC | SND_LOOP);
            }
            alarm_active = 1;

         }
         else
         {
            if (alarm_active == 1 && (now - start) > 1000) {
               PlaySound(NULL, NULL, SND_ASYNC | SND_LOOP);
               alarm_active = 0;
            }



         }
      }

      //display_graph_data();
   }
   return 0;
}


void CBlueTooth::read_flash_block()
{
   // TODO: Add your implementation code here.
   int x, y, z, nbytes, i, sent;
   FILE *stream;
   unsigned char buffer[100];
   unsigned char wb[20];
   unsigned char temp[10];
   unsigned long address, data1, data2, data3, data4;
   unsigned short test[3];

   flush();
   wb[0] = 'R';
   wb[1] = 'e';
   wb[2] = 'a';
   wb[3] = 'd';
   wb[4] = 'f';
   sent = send(BtSocket, (char *)wb, 5, 0);
   flush();

   Sleep(500);

   y = 0;
   for (x = 0; x < 37; ++x)
   {
      nbytes = ReadBluetooth((unsigned char *)rx1);

      Crc8 = 0;
      for (i = 0; i < rxsize - 1; ++i)
         UpdateCRC8(rx1[i]);

      if (Crc8 != rx1[rxsize - 1])
         m_pMainGui->wPrintf(_T("CRC Error"));

      for (z = 2; z < 43; ++z)
      {
         Flash_Block[y] = rx1[z];
         y = y + 1;
      }
   }
   nbytes = ReadBluetooth((unsigned char *)rx1);

   Crc8 = 0;
   for (i = 0; i < rxsize - 1; ++i)
      UpdateCRC8(rx1[i]);

   if (Crc8 != rx1[rxsize - 1])
      m_pMainGui->wPrintf(_T("CRC Error"));

   for (z = 2; z < 21; ++z)
   {
      Flash_Block[y] = rx1[z];
      y = y + 1;
   }
   m_pMainGui->wPrintf(_T("Done"));
}


void CBlueTooth::write_flash_block()
{
   // TODO: Add your implementation code here.
   int x, y, z, nbytes, i, sent;
   FILE *stream;
   unsigned char buffer[100];
   unsigned char wb[20];
   unsigned char temp[10];
   unsigned long address, data1, data2, data3, data4;
   unsigned short test[3];

   y = 0;
   for (x = 0; x < 1536; ++x)
   {
      Flash_Block[x] = y;
      y = y + 1;
      if (y == 255)
         y = 0;
   }

   flush();
   wb[0] = 'W';
   wb[1] = 'r';
   wb[2] = 'i';
   wb[3] = 't';
   wb[4] = 'f';
   sent = send(BtSocket, (char *)wb, 5, 0);
   flush();

   Sleep(500);

   y = 0;
   for (x = 0; x < 37; ++x)
   {
      for (z = 0; z < 41; ++z)
      {
         buffer[z] = Flash_Block[y];
         y = y + 1;
      }

      sent = send(BtSocket, (char *)buffer, 41, 0);
      Sleep(100);
   }

   Sleep(100);

   for (z = 0; z < 19; ++z)
   {
      buffer[z] = Flash_Block[y];
      y = y + 1;
   }
   //
   //	Send 41 but really only 19 of that are used on the other end
   //	The other side expects a certain packet size
   //
   sent = send(BtSocket, (char *)buffer, 41, 0);

   m_pMainGui->wPrintf(_T("Done"));
}


void CBlueTooth::UpdateCRC8(unsigned char c)
{
   // TODO: Add your implementation code here.
   Crc8 = TableCrc8[Crc8 ^ c];
}


void CBlueTooth::download_new_program()
{
   // TODO: Add your implementation code here.
   int x, y, z, nbytes, i, sent;
   FILE *stream;
   unsigned char buffer[100], buff2[50], buff1[50];
   unsigned char wb[20];
   unsigned char temp[10];
   unsigned long address, data1, data2, data3, data4;
   unsigned short test[3];
   int progress, prog, saved_prog;

   prog = 0;
   saved_prog = 0;
   progress = 0;
   stream = 0;

   m_pMainGui->wPrintf(_T("Download new program function called"));
   //
   //	First ask micro if it's running the infrared program or the loader.
   //	If it's already running the loader then just continue on with the
   //	code. 
   //
   //	If it's running the infrared code we need to send it a command
   //	to put itself into loader mode. After that we need to close the 
   //	Bluetooth connection, wait a bit then wait for a reconnect from
   //	the loader then continue on.
   //
   m_pMainGui->wPrintf(_T("Asking micro what mode it's in"));
   flush();
   wb[0] = 'M';
   wb[1] = 'o';
   wb[2] = 'd';
   wb[3] = 'e';
   wb[4] = '?';
   sent = send(BtSocket, (char *)wb, 5, 0);
   flush();
   //
   //	Wait for response msg to come back
   //
   nbytes = ReadBluetooth((unsigned char *)rx1);


   m_pMainGui->wPrintf(_T("nbytes=%d %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x"), nbytes,
      rx1[0],
      rx1[1],
      rx1[2],
      rx1[3],
      rx1[4],
      rx1[5],
      rx1[6],
      rx1[7],
      rx1[8],
      rx1[9],
      rx1[10],
      rx1[11]);




   if (strncmp("Infrared", (const char *)&rx1[3], 8) == 0)
   {
      m_pMainGui->wPrintf(_T("Received an message back, micro is running infrared code"));
      //
      //	Stop the infrared code. Need to shut down normally and cool down the laser
      //
      m_pMainGui->wPrintf(_T("sending stop"));
      flush();
      wb[0] = 'S';
      wb[1] = 't';
      wb[2] = 'o';
      wb[3] = 'p';
      wb[4] = ' ';
      sent = send(BtSocket, (char *)wb, 5, 0);
      flush();

      Sleep(10000);
      //
      //	Tell the infrared code to jump into loader mode
      //
      m_pMainGui->wPrintf(_T("sending jump to loader command"));
      flush();
      wb[0] = 'L';
      wb[1] = 'o';
      wb[2] = 'a';
      wb[3] = 'd';
      wb[4] = ' ';
      sent = send(BtSocket, (char *)wb, 5, 0);
      flush();
      //
      // 	Close the socket
      //
      x = shutdown(BtSocket, SD_BOTH);
      if (SOCKET_ERROR == closesocket(BtSocket))
         m_pMainGui->wPrintf(_T("=CRITICAL= | closesocket() call failed w/socket = [0x%I64X]. WSAGetLastError=[%d]\n"), (ULONG64)BtSocket, WSAGetLastError());
      BtSocket = INVALID_SOCKET;
      if (INVALID_SOCKET != BtSocket)
      {
         closesocket(BtSocket);
         BtSocket = INVALID_SOCKET;
      }
      WSACleanup();

      PlaySound(TEXT("c:\\bascomturner\\program\\ding.wav"), NULL, SND_ASYNC | SND_LOOP);
      Sleep(2000);
      PlaySound(NULL, NULL, SND_ASYNC | SND_LOOP);



      //
      //	Uncheck connected box
      //
      //btconn->SetSel(0, -1);
      //btconn->Clear();
      //
      //	Now lets sleep a bit and wait for the infrared code to write the new int vectors
      //	then switch to the loader code then we'll re-connect the Bluetooth
      //
      Sleep(10000);


      for (;;)
      {
         x = Look_For_Bluetooth_Devices();
         if (x == 1)
            break;
      }
      m_Settings.m_ConnectionStatus.bBluetooth = true;
      //test[0] = 254;
      //test[1] = 0;
      //test[2] = 0;
      //btconn->SetSel(0, -1);
      //btconn->Clear();
      //btconn->ReplaceSel((LPCTSTR)&test[0], FALSE);

      PlaySound(TEXT("c:\\bascomturner\\program\\ding.wav"), NULL, SND_ASYNC | SND_LOOP);
      Sleep(2000);
      PlaySound(NULL, NULL, SND_ASYNC | SND_LOOP);
   }
   //
   //	If we received back a Loader message just fall through.
   //	We fall through from above if that code executes also.
   //
   if (strncmp("Loader", (const char *)&rx1[3], 6) == 0)
   {
      m_pMainGui->wPrintf(_T("Received a message back, micro is running loader code"));
   }

   m_pMainGui->wPrintf(_T("sending prog"));
   flush();
   wb[0] = 'P';
   wb[1] = 'r';
   wb[2] = 'o';
   wb[3] = 'g';
   wb[4] = ' ';
   sent = send(BtSocket, (char *)wb, 5, 0);
   flush();
   //
   //	Wait for OK msg to come back
   //
   nbytes = ReadBluetooth((unsigned char *)rx1);

   m_pMainGui->wPrintf(_T("Received an OK message back"));

   for (x = 0; x < 100; ++x)
      buffer[x] = 0;


   //	stream = fopen("c:\\BascomTurner\\Program\\TestLoad.production.hex", "r");
   stream = fopen("c:\\BascomTurner\\Program\\Infrared.hex", "r");


   //
   //	Don't want very first line. It's the header
   //
   for (;;)
   {
      i = fread(&buffer[0], 1, 1, stream);
      if (buffer[0] == 0x0A)
         break;
   }

   for (x = 0; x < 100; ++x)
      buffer[x] = 0;

   i = 0;
   x = 0;
   z = 0;

   for (;;)
   {
      i = fread(&buffer[x], 1, 1, stream);
      if (i <= 0)
         break;

      z = z + 1;

      if (z > 5 && z < 14)
         continue;

      if (z > 19 && z < 24)
         continue;

      if (z > 29 && z < 34)
         continue;

      if (z > 39 && z < 44)
         continue;

      if (z > 49 && z < 71)
         continue;

      if (z == 84)
      {
         temp[0] = buffer[0];
         temp[1] = buffer[1];
         temp[2] = buffer[2];
         temp[3] = buffer[3];
         temp[4] = buffer[4];
         temp[5] = 0;
         sscanf((const char *)&temp[0], "%lx", (const char *)&address);

         temp[0] = buffer[5];
         temp[1] = buffer[6];
         temp[2] = buffer[7];
         temp[3] = buffer[8];
         temp[4] = buffer[9];
         temp[5] = buffer[10];
         temp[6] = 0;
         sscanf((const char *)&temp[0], "%lx", (const char *)&data1);

         temp[0] = buffer[11];
         temp[1] = buffer[12];
         temp[2] = buffer[13];
         temp[3] = buffer[14];
         temp[4] = buffer[15];
         temp[5] = buffer[16];
         temp[6] = 0;
         sscanf((const char *)&temp[0], "%lx", (const char *)&data2);

         temp[0] = buffer[17];
         temp[1] = buffer[18];
         temp[2] = buffer[19];
         temp[3] = buffer[20];
         temp[4] = buffer[21];
         temp[5] = buffer[22];
         temp[6] = 0;
         sscanf((const char *)&temp[0], "%lx", (const char *)&data3);

         temp[0] = buffer[23];
         temp[1] = buffer[24];
         temp[2] = buffer[25];
         temp[3] = buffer[26];
         temp[4] = buffer[27];
         temp[5] = buffer[28];
         temp[6] = 0;
         sscanf((const char *)&temp[0], "%lx", (const char *)&data4);

         if (data1 == 0xffffff && data2 == 0xffffff && data3 == 0xffffff && data4 == 0xffffff)
         {
            for (x = 0; x < 100; ++x)
               buffer[x] = 0;
            z = 0;
            x = 0;
            continue;
         }
         //
         //	Skip this range. This is the loaders C-Lib area
         //
         if (address >= 0x3800 && address < 0x7000)
         {
            for (x = 0; x < 100; ++x)
               buffer[x] = 0;
            z = 0;
            x = 0;
            continue;
         }
         //
         //	Skip this range. This is the actual loader code at 13c00. At 13800 is
         //	our saved block of flash to store stuff.. We could actually break at this 
         //	point since nothing else will be going across but I'm not going to push it. It 
         //	works good now. Fuck You Brian. By the time you read this I'll probably be either
         //	in Alaska or on my way or eaten by a bear.
         //
         if (address >= 0x13800)
         {
            for (x = 0; x < 100; ++x)
               buffer[x] = 0;
            z = 0;
            x = 0;
            continue;
         }

         buffer[29] = 0;




         prog = progress / 25;


         if (prog != saved_prog)
         {
            saved_prog = prog;

            for (x = 0; x < 40; ++x)
               buff1[x] = 0;
            m_pMainGui->m_plotGraph.Updateppm(prog);
            //PPM->SetSel(0, -1);
            //PPM->Clear();
            //sprintf((char *const)&buff2[0], "%d%%", prog);
            //buff1[0] = buff2[0];
            //buff1[2] = buff2[1];
            //buff1[4] = buff2[2];
            //buff1[6] = buff2[3];
            //PPM->ReplaceSel((LPCTSTR)&buff1[0], FALSE);
         }
         progress = progress + 1;













         sent = send(BtSocket, (char *)buffer, 29, 0);
         for (x = 0; x < 100; ++x)
            buffer[x] = 0;
         //
         //		Wait for OK msg to come back
         //
         nbytes = ReadBluetooth((unsigned char *)rx1);

         z = 0;
         x = 0;
         continue;
      }
      x = x + 1;
   }
   for (x = 0; x < 100; ++x)
      buffer[x] = 0;

   buffer[0] = 'F';
   buffer[1] = 'F';
   buffer[2] = 'F';
   buffer[3] = 'F';
   buffer[4] = 'F';
   sent = send(BtSocket, (char *)buffer, 29, 0);
   //
   // 	Close the socket
   //
   x = shutdown(BtSocket, SD_BOTH);
   if (SOCKET_ERROR == closesocket(BtSocket))
      m_pMainGui->wPrintf(_T("=CRITICAL= | closesocket() call failed w/socket = [0x%I64X]. WSAGetLastError=[%d]\n"), (ULONG64)BtSocket, WSAGetLastError());
   BtSocket = INVALID_SOCKET;
   if (INVALID_SOCKET != BtSocket)
   {
      closesocket(BtSocket);
      BtSocket = INVALID_SOCKET;
   }
   WSACleanup();

   PlaySound(TEXT("c:\\bascomturner\\program\\ding.wav"), NULL, SND_ASYNC | SND_LOOP);
   Sleep(2000);
   PlaySound(NULL, NULL, SND_ASYNC | SND_LOOP);
   //
   //	Uncheck connected box
   //
   //btconn->SetSel(0, -1);
   //btconn->Clear();
   //
   //	Now lets sleep a bit and wait for the infrared code to write the new int vectors
   //	then switch to the loader code then we'll re-connect the Bluetooth
   //
   Sleep(10000);


   for (;;)
   {
      x = Look_For_Bluetooth_Devices();
      if (x == 1)
         break;
   }
   m_Settings.m_ConnectionStatus.bBluetooth;
   //test[0] = 254;
   //test[1] = 0;
   //test[2] = 0;
   //btconn->SetSel(0, -1);
   //btconn->Clear();
   //btconn->ReplaceSel((LPCTSTR)&test[0], FALSE);

   PlaySound(TEXT("c:\\bascomturner\\program\\ding.wav"), NULL, SND_ASYNC | SND_LOOP);
   Sleep(2000);
   PlaySound(NULL, NULL, SND_ASYNC | SND_LOOP);


   m_pMainGui->wPrintf(_T("Done, setting mode to idle"));
   Mode = 2;		// idle
   fclose(stream);
   return;
}

